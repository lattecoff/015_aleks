import Dishes

class MainCourses(Dishes):
    def get_name(self):
        return self.name

    def get_cuisune(self):
        return self.cuisine

""" End of file. """
